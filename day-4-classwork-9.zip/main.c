/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<string.h>
union Data{
    int i;
    float f;
    char str[20];
};
 int main (){
     union Data data;
     data.i=10;
     data.f=220.5;
     strcpy(data.str,"c programing");
     
     printf("data.i:%d\n",data.i);
     printf("data.f%f\n",data.f);
     printf("data.str:%s\n",data.str);
     return 0;
 }
