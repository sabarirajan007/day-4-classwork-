/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
# include <stdio.h>
# include <conio.h>
struct  employee
{
char name[50] ;
int empId ;
int age ;
float salary ;
} ;

int  main( )
{
struct employee emp ;
printf("\n Enter employee details !\n") ;
printf("\n Name : ") ;
scanf("%s",&emp.name ) ;
printf("\n ID : ") ;
scanf("%d",&emp.empId ) ;
printf("\n Age : ") ;
scanf("%d",&emp.age ) ;
printf("\n Salary : ") ;
scanf("%f",&emp.salary ) ;

printf("\n Entered employee detail are !" ) ;
printf("\n Name: %s" ,emp.name ) ;
printf("\n Id: %d" ,emp.empId ) ;
printf("\n age: %d" ,emp.age ) ;
printf("\n Salary: %f\n",emp.salary ) ;
return 0 ;
}